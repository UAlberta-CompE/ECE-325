package ece325.labs.lab2;

/**
 * Represents a Chair furniture item.
 */
public class Chair extends Furniture {
    public Chair() {
        super();
    }

    /**
     * Returns "Chair" as the type.
     */
    @Override
    public String toString() {
        return "Chair";
    }
}
