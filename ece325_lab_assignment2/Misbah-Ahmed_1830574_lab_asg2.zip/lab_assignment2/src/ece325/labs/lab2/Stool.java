package ece325.labs.lab2;

/**
 * Represents a Stool furniture item.
 */
public class Stool extends Furniture {
    public Stool() {
        super();
    }

    /**
     * Returns "Stool" as the type.
     */
    @Override
    public String toString() {
        return "Stool";
    }
}
